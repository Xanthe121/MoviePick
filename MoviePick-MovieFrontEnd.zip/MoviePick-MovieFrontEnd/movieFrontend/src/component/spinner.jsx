import React from "react";

const spinner = () =>{
    return (
        <div>Spinner</div>
    )
}

export default Spinner