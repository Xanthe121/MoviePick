import React from "react";

const MovieCard = ({ movie: { title, genre, duration, rating, poster_path, showtimes:{ time, availableSeats } } }) => {
    console.log(poster_path);
    return (
        <div className="movie-card">
            <img
                src={poster_path ?
                    `${poster_path}` : '/no-movie.png'}
                alt={title}
            />
            <p className='movie-name'>{title}</p>
        </div>
    )
}

export default MovieCard